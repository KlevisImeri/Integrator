#ifndef menu
#define menu

#include <stdio.h>
#include <stdlib.h>

void start_menu(double *partition, double *lower_bound, double *upper_bound);

#endif