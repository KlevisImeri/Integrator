gcc -std=c99 main.c charlib.c  bitmap.c  chararray.c  cursorlib.c nodelib.c  parserlib.c menu.c -lm
